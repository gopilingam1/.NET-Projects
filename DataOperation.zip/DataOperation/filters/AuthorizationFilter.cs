using DataOperation.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
public class AuthorizeActionFilter : IAuthorizationFilter
{
    private readonly string _permission;
    public AuthorizeActionFilter(string permission)
    {
        this._permission = permission;
    }
    public void OnAuthorization(AuthorizationFilterContext context)
    {
        bool isAuthorized = CheckUserPermission(context.HttpContext.Session.GetString("Emailid"), context.RouteData.Values["controller"].ToString());
        if (!isAuthorized)
        {
            context.Result = new UnauthorizedResult();
        }
    }
    public bool CheckUserPermission(string email, string controllerName)
    {
        List<KeyValue> accessList;
        KeyValue accessModel;
        try
        {
            if (Database.AccessPrevilageList == null || Database.AccessPrevilageList.Count == 0) { return false; }
            if (!Database.AccessPrevilageList.ContainsKey(email)) { return false; }
            accessList = Database.AccessPrevilageList[email];
            if (accessList == null || accessList.Count == 0) { return false; }
            accessModel = accessList.Find(e => e.Key == controllerName);
            if (accessModel == null || !(accessModel.Value ?? "").Contains(this._permission)) { return false; }
            return true;
        }
        finally
        {
            accessList = null;
            accessModel = null;
        }

    }
}

public class AuthorizeAttribute : TypeFilterAttribute
{
    public AuthorizeAttribute(string permission)
        : base(typeof(AuthorizeActionFilter))
    {
        Arguments = new object[] { permission };
    }
}
