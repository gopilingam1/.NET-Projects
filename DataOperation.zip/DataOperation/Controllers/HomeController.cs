﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using DataOperation.Models;

namespace DataOperation.Controllers;

[Authorize("Read")]
public class HomeController : Controller
{
    public static string authorizationLevel = "";

    private readonly ILogger<HomeController> _logger;

    public HomeController()
    {

    }

    [Authorize("Read")]
    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
