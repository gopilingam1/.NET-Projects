using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using DataOperation.Models;

namespace DataOperation.Controllers;

public class LoginController : Controller
{
    public string authorizationLevel = "";

    public LoginController()
    {

    }

    public IActionResult Index()
    {
        return View(new LoginModel());
    }


    [HttpPost]
    public IActionResult Login(LoginModel luser)
    {
        UserMaster userModel;
        try
        {
            if (luser == null) { ViewBag.ErrorMsg = "Please Fill The Form First."; return View("Index", new LoginModel()); }
            if (string.IsNullOrWhiteSpace(luser.LoginEmail)) { ViewBag.ErrorMsg = "Please Fill Login Id."; return View("Index", luser); }
            if (string.IsNullOrWhiteSpace(luser.LoginPassword)) { ViewBag.ErrorMsg = "Please Fill Password."; return View("Index", luser); }

            if (Database.UserMaster == null || Database.UserMaster.Count == 0)
            {
                ViewBag.ErrorMsg = "No user Found. Please contact admin."; return View("Index", luser);
            }
            userModel = Database.UserMaster.Find(e => e.LoginId == luser.LoginEmail);
            if (userModel == null || userModel.Password != luser.LoginPassword) { ViewBag.ErrorMsg = "Please enter valid user name and password."; return View("Index", luser); }
            HttpContext.Session.SetString("Emailid", luser.LoginEmail);
            return RedirectToAction("Privacy", "Home");
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message ?? "" + e.StackTrace ?? "");
            return StatusCode(500, "Check The Error In Your Terminal..");
        }
    }







    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
