// namespace DataOperation.Models;
// public static class SessionStorage
// {
//     public static void SetSession(HttpContext httpContext, string key, string value)
//     {
//         httpContext.Session.SetString(key, value);
//     }

//     public static string GetSession(HttpContext httpContext, string key)
//     {
//         return httpContext.Session.GetString(key);
//     }
// }
