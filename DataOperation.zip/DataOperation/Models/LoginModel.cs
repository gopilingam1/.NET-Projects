namespace DataOperation.Models;
public class LoginModel
{
    public int Id { get; set; }
    public string LoginEmail { get; set; }
    public string LoginPassword { get; set; }
}

public class UserMaster
{
    public string LoginId { get; set; }
    public string Password { get; set; }
}
public class KeyValue
{
    public string Key { get; set; }
    public string Value { get; set; }
}