namespace DataOperation.Models;
public static class Database
{
    public static Dictionary<string, string> loginUsers = new Dictionary<string, string>
    {
        { "gopi@gmail.com", "read" },
        { "surya@gmail.com", "write" },
        { "selva@gmail.com", "edit" }
    };
    public static List<LoginModel> loginData = new List<LoginModel>();

    public static List<UserMaster> UserMaster = new List<UserMaster>() {
            new UserMaster { LoginId ="gopi@gmail.com", Password="1" },
            new UserMaster { LoginId ="surya@gmail.com", Password="1" },
            new UserMaster { LoginId ="selva@gmail.com", Password="1" }
        };

    public static Dictionary<string, List<KeyValue>> AccessPrevilageList = new Dictionary<string, List<KeyValue>>
    {
        { "gopi@gmail.com", new List<KeyValue>(){ new KeyValue { Key ="Home", Value="Read,Write"}} },
        { "surya@gmail.com", new List<KeyValue>(){ new KeyValue { Key ="Home", Value="Read"}} },
        { "selva@gmail.com", new List<KeyValue>(){ new KeyValue { Key ="Home", Value="Write"} } }
    };

}
